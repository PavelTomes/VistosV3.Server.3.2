﻿





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetEntityListParam : IRequestParam
    {
        public string EntityName { get; set; }
    }
}