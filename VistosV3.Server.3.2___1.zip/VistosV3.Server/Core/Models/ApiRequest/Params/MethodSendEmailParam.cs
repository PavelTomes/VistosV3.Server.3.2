﻿





namespace Core.Models.ApiRequest.Params
{
    //public class MethodSendEmailParam : IRequestParam
    //{
    //    public int EmailId { get; set; }
    //}
}