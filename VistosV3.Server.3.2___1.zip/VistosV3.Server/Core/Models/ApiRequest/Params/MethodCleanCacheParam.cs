﻿




namespace Core.Models.ApiRequest.Params
{
    public class MethodCleanCacheParam
    {

    }
}