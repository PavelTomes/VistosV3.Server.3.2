﻿using Newtonsoft.Json.Linq;





namespace Core.Models.ApiRequest.Params
{
    public class MethodSaveLocalizationParam
    {
        public JArray Data { get; set; }
    }
}