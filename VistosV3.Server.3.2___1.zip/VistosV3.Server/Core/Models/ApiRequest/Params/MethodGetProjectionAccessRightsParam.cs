﻿using Newtonsoft.Json.Linq;





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetProjectionAccessRightsParam
    {
        public JObject Filter { get; set; }
    }
}