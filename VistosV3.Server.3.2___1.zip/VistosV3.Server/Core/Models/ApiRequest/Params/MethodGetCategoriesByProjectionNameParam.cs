﻿





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetCategoriesByProjectionNameParam : IRequestParam
    {
        public string ProjectionName { get; set; }
    }
}