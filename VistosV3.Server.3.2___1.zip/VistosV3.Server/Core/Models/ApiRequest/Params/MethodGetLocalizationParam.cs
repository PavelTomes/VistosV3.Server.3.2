﻿using Newtonsoft.Json.Linq;





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetLocalizationParam
    {
        public JObject Filter { get; set; }
    }
}