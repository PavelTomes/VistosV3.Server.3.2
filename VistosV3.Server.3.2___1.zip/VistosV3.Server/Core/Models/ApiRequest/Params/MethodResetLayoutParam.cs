﻿




namespace Core.Models.ApiRequest.Params
{
    public class MethodResetLayoutParam
    {
        public string EntityName { get; set; }
        public string Mode { get; set; }
    }
}