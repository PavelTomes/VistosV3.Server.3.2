﻿





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetSchemaParam : IRequestParam
    {
        public string EntityName { get; set; }
    }
}