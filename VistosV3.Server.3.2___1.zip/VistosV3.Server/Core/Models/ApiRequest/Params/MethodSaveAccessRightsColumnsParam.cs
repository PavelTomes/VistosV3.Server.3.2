﻿using Newtonsoft.Json.Linq;





namespace Core.Models.ApiRequest.Params
{
    public class MethodSaveAccessRightsColumnsParam
    {
        public JArray Data { get; set; }
    }
}