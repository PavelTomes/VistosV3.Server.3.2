﻿





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetMenuParam : IRequestParam
    {
        public string EntityName { get; set; }
    }
}