﻿using Newtonsoft.Json.Linq;





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetDiscussionByEntitParam
    {
        public int RecordId { get; set; }
        public string ProjectionName { get; set; }
    }
}