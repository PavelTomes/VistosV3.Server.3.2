﻿





namespace Core.Models.ApiRequest.Params
{

    public class MethodAddSignatureParam : IRequestParam
    {
        public string Data { get; set; }
    }
}