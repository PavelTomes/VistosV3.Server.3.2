﻿using Newtonsoft.Json.Linq;





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetAccessRightsColumnByProjection
    {
        public JObject Filter { get; set; }
    }
}