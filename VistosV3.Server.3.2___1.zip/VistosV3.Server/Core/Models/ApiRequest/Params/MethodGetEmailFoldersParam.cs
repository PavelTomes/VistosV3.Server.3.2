﻿





namespace Core.Models.ApiRequest.Params
{
    public class MethodGetEmailFoldersParam : IRequestParam
    {
    }
}