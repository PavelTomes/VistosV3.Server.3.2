﻿




namespace Core.Models.ApiRequest.Params
{
    public class MethodSaveDiscussionMessageParam
    {
        public string HierarchyId { get; set; }
        public int RecordId { get; set; }
        public string ProjectionName { get; set; }
        public string Text { get; set; }
    }
}