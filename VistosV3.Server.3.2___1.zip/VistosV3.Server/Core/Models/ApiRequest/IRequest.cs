﻿


using System.Text;
using System.Threading.Tasks;

namespace Core.Models.ApiRequest
{
    public interface IRequestParam
    {
    }

}
