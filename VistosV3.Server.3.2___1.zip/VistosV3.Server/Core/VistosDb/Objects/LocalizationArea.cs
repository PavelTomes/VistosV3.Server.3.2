namespace Core.VistosDb.Objects
{
    using System;
    using System.Collections.Generic;
    
    public partial class LocalizationArea
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
