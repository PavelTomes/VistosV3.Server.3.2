namespace Core.VistosDb.Objects
{
    using System;
    using System.Collections.Generic;


    public partial class vwRole
    {
        
        public int Role_ID { get; set; }
        public string Role_Name { get; set; }
        public string Role_Caption { get; set; }
    }
}
