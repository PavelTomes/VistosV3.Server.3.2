namespace Core.VistosDb.Objects
{
    using System;
    using System.Collections.Generic;
    
    public partial class CrmEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Type { get; set; }
    }
}
